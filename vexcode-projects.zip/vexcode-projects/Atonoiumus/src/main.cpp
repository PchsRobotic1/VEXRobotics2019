// To complete the VEXcode V5 Text project upgrade process, please follow the
// steps below.
// 
// 1. You can use the Robot Configuration window to recreate your V5 devices
//   - including any motors, sensors, 3-wire devices, and controllers.
// 
// 2. All previous code located in main.cpp has now been commented out. You
//   will need to migrate this code to the new "int main" structure created
//   below and keep in mind any new device names you may have set from the
//   Robot Configuration window. 
// 
// If you would like to go back to your original project, a complete backup
// of your original (pre-upgraded) project was created in a backup folder
// inside of this project's folder.

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

//int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  //vexcodeInit();
  
//}

// /*----------------------------------------------------------------------------*/
// /*                                                                            */
// /*    Module:       main.cpp                                                  */
// /*    Author:       C:\Users\Student                                          */
// /*    Created:      Tue Sep 17 2019                                           */
// /*    Description:  V5 project                                                */
// /*                                                                            */
// /*----------------------------------------------------------------------------*/
// #include "vex.h"
// 
// // ---- START VEXCODE CONFIGURED DEVICES ----
// // Robot Configuration:
// // [Name]               [Type]        [Port(s)]
// // ---- END VEXCODE CONFIGURED DEVICES ----
// 
// using namespace vex;
// 
// 
    
    
    
    
    vex::motor LeftMotor   = vex::motor( vex::PORT1, false );
    vex::motor RightMotor  = vex::motor( vex::PORT10,false );
// 
// // A global instance of vex::brain used for printing to the V5 brain screen
    vex::brain       Brain;
    
    // define your global instances of motors and other devices here
// 
// //Defining Function to go straight
    double straight(double x) {
      double dist=x;
        double deg;
        //converts linear to degress
        deg =(360*dist)/(6.28*2);
        //startRotateFor makes both happen at same time
       RightMotor.startRotateFor(vex::directionType::fwd,(deg), vex::rotationUnits::deg, (30), vex::velocityUnits::pct);
       LeftMotor.rotateFor(vex::directionType::fwd,(-1*deg), vex::rotationUnits::deg,(30), vex::velocityUnits::pct);
       return double (x);
    }
    double turnLeft(double DegOfTurn){
      double deg;
      // the degree it turns is 1/6 of the degree we give it so we times it by 6.
      deg=(6*DegOfTurn);
      RightMotor.startRotateFor(vex::directionType::fwd,(2*deg), vex::rotationUnits::deg, (50), vex::velocityUnits::pct);
      return double(DegOfTurn);
    }
    double turnRight(double DegOfTurn){
      double deg;
      // the degree it turns is 1/6 of the degree we give it so we times it by 6.
      deg=(6*DegOfTurn);
      LeftMotor.startRotateFor(vex::directionType::fwd,(2*deg), vex::rotationUnits::deg, (50), vex::velocityUnits::pct);
      //LeftMotor.startRotateFor(double rotation, rotationUnits units, double velocity, velocityUnits units_v)
      return double(DegOfTurn);
    }
    double straightandTurn(double dista, double angle){
      straight(dista);
      turnLeft(angle);
      return double(dista+angle);
    }
    int main() {
    straight(60);
    turnRight(90);

    } 